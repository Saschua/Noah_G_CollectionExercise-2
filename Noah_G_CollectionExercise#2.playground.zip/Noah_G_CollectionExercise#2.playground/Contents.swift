import UIKit

var videogames: [String] = ["Assassins Creed", "Persona"]
videogames += ["Horizon Zero Dawn"]
videogames += ["Brawlhalla"]
videogames += ["Batman Arkham Knight"]
videogames += ["Marvels Spiderman"]

videogames.sort()

print; videogames
